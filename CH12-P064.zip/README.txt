CH12-P064 render package. 1024x1536 canvas. Generate three separate coordinated files:
IAKESI-CH12-064-art.png (no balloons, lettering or folio)
IAKESI-CH12-064-lettering.png (transparent RGBA overlay, same registration)
IAKESI-CH12-064-text.txt (exact wording from supplied transcript)
All CAPS CSP final lettering. Follow scene ownership and tail rules. Do not render production directions, page numbers or panel numbers.
