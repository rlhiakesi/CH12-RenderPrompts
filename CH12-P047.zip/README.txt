CH12-P047 render package. 1024x1536 canvas. Generate three separate coordinated files:
IAKESI-CH12-047-art.png (no balloons, lettering or folio)
IAKESI-CH12-047-lettering.png (transparent RGBA overlay, same registration)
IAKESI-CH12-047-text.txt (exact wording from supplied transcript)
All CAPS CSP final lettering. Follow scene ownership and tail rules. Do not render production directions, page numbers or panel numbers.
